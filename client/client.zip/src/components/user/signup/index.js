import React, { Component } from 'react';
import './index.css';
import { GoogleLogin } from 'react-google-login';


export default class Signup extends Component {
    responseGoogleSucess = (res) => {
        console.log(res, "res");
    }
    responseGoogleFailure = (res) => {
        console.log(res, 'resss')
    }
    render() {
        return (
            <div>
                <div className="modal fade" id="exampleModalCenter1" tabIndex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div className="modal-dialog modal-dialog-centered" role="document">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title" id="exampleModalLongTitle">Sign Up</h5>
                                <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div className="modal-body">
                                <div className="container">
                                    <div style={{ textAlign: 'center' }}>
                                        <GoogleLogin
                                            clientId="287896331947-9cv5a36uqtau1gioubths591jqtarhdt.apps.googleusercontent.com"
                                            buttonText="Signup with Google"
                                            onSuccess={(res) => this.responseGoogleSucess(res)}
                                            onFailure={(res) => this.responseGoogleFailure(res)}
                                        >
                                        </GoogleLogin>                                    </div>
                                    <div style={{ textAlign: 'center' }}>
                                        <span className="text-muted text-center">or</span>
                                    </div>
                                    <hr style={{ width: '50%' }} />
                                    <div className="input-group" style={{ paddingTop: "40px" }}>
                                        <div className="input-group-prepend">
                                        </div>
                                        <input type="text" className="form-control" placeholder="Enter Full Name" style={{ paddingBottom: "15px", paddingTop: "15px" }} />
                                    </div>
                                    <div className="input-group" style={{ paddingTop: "40px", paddingBottom: "40px" }}>
                                        <div className="input-group-prepend">
                                            <span id="inputGroupPrepend2" className="btn btn-light input-group-text" style={{ border: "thick" }}>@</span>
                                        </div>
                                        <input type="email" className="form-control" placeholder="Enter Email" style={{ paddingBottom: "15px", paddingTop: "15px" }} />
                                    </div>
                                </div>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-light btnVeryfy">Verify Email</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
} 